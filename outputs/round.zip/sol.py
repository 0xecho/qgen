# {
#     "title": "Roundabouts",
#     "short_title": "round",
#     "time_limit": 1,
#     "uva_id": 12582,
#     "balloon_color": "#0000ff",
#     "body": [
#         "Finals are over!!! Hurray!!!",
#         "But now you have all this time on your hands and nothing to do. So you decide to walk outside to clear your head. As you are walking you see a sign that says, 'Park Roundabout', and you decide to go in. As soon as you enter the park you find your self in a round about with multiple roads leading to other roundabouts. You wanted to checkout every roundabout in the park and how well they are connected so you developed a plan to figure that out. You opened your notepad and came up with the following plan",
#         "1. Everytime you ENTER a roundabout for the FIRST time, you write it's name in your note book",
#         "2. Everytime you LEAVE a roundabout for the LAST time, you write it's name in your note book",
#         "3. You never go back to a roundabout you visited while there are unvisited roundabouts you can go from where you are.",
#         "All roundabouts in the park are already given names, which is just a single uppercase letter.",
#         "After you have finished walking through the park, you want to figure out how many roundabouts each round about is connected to.",
#         "For Example: In the image above, the main entrance leads to roundabout A.",
#         "You start from roundabout A and since its the first time you are visitng A, you jot it down in the notepad. Then you can either go to E or B, let's say you went to E. You would jot down E then again choose between F and G. Note that you cannot go back to A because there are previously unvisited roundabouts you can get to from where you are. If you go to F, you write F down. Since there are no more roundabouts from F, you go back to E. The you go to G, jot it down and come back to E. Now that you are done from E, you can go back to A. From A you can get to B. From B you can go to D or C. So let's say you wen to D then back to B then C then B then A. After all this you will find in your notebook: AEFFGGEBDDCCBA."
#     ],
#     "input": {
#         "description": "The first line of input contains one integer, T, the number of test cases. The next T lines contain one string each. Each string contains the name of a roundabout. A name is a single uppercase letter."
#     },
#     "output": {
#         "description": "For each test case, you must output the case number in the format shown below, followed the number of connected roundabouts for each roundabout in a sorter order of the names of the roundabouts."
#     },
#     "samples": [
#         {
#             "input": [
#                 "2",
#                 "AEFFGGEBDDCCBA",
#                 "ZAABBZ"
#             ],
#             "output": [
#                 "Case 1",
#                 "A = 2",
#                 "B = 3",
#                 "C = 1",
#                 "D = 1",
#                 "E = 3",
#                 "F = 1",
#                 "G = 1",
#                 "Case 2",
#                 "A = 1",
#                 "B = 1",
#                 "Z = 2"
#             ]
#         }
#     ],
#     "testcases": {
#         "input_paths": [],
#         "output_paths": []
#     }
# }
T = int(input())
for _ in range(T):
    roundabouts = input()
    COUNT = {}
    stack = []
    for r in roundabouts:
        if stack:
            if stack[-1] == r:
                stack.pop()
            else:
                last_roundabout = stack[-1]
                COUNT[last_roundabout] = COUNT.get(last_roundabout, 0) + 1
                COUNT[r] = COUNT.get(r, 0) + 1
                stack.append(r)
        else:
            stack.append(r)
    print("Case {}".format(_+1))
    for k, v in sorted(COUNT.items()):
        print("{} = {}".format(k, v))
