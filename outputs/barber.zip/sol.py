def get_all_possible(grid, ridx, cidx):
    all_possible_words = set()
    all_possible_words.update(get_all_possible_left(grid, ridx, cidx))
    all_possible_words.update(get_all_possible_right(grid, ridx, cidx))
    all_possible_words.update(get_all_possible_up(grid, ridx, cidx))
    all_possible_words.update(get_all_possible_down(grid, ridx, cidx))
    all_possible_words.update(get_all_possible_up_left(grid, ridx, cidx))
    all_possible_words.update(get_all_possible_up_right(grid, ridx, cidx))
    all_possible_words.update(get_all_possible_down_left(grid, ridx, cidx))
    all_possible_words.update(get_all_possible_down_right(grid, ridx, cidx))
    return all_possible_words

def get_all_possible_left(grid, ridx, cidx):
    all_possible_words = set()
    running_word = ""
    for cidx in range(cidx, -1, -1):
        running_word += grid[ridx][cidx]
        all_possible_words.add(running_word)
    return all_possible_words

def get_all_possible_right(grid, ridx, cidx):
    all_possible_words = set()
    running_word = ""
    for cidx in range(cidx, len(grid[0])):
        running_word += grid[ridx][cidx]
        all_possible_words.add(running_word)
    return all_possible_words

def get_all_possible_up(grid, ridx, cidx):
    all_possible_words = set()
    running_word = ""
    for ridx in range(ridx, -1, -1):
        running_word += grid[ridx][cidx]
        all_possible_words.add(running_word)
    return all_possible_words

def get_all_possible_down(grid, ridx, cidx):
    all_possible_words = set()
    running_word = ""
    for ridx in range(ridx, len(grid)):
        running_word += grid[ridx][cidx]
        all_possible_words.add(running_word)
    return all_possible_words

def get_all_possible_up_left(grid, ridx, cidx):
    all_possible_words = set()
    running_word = ""
    for ridx, cidx in zip(range(ridx, -1, -1), range(cidx, -1, -1)):
        running_word += grid[ridx][cidx]
        all_possible_words.add(running_word)
    return all_possible_words

def get_all_possible_up_right(grid, ridx, cidx):
    all_possible_words = set()
    running_word = ""
    for ridx, cidx in zip(range(ridx, -1, -1), range(cidx, len(grid[0]))):
        running_word += grid[ridx][cidx]
        all_possible_words.add(running_word)
    return all_possible_words

def get_all_possible_down_left(grid, ridx, cidx):
    all_possible_words = set()
    running_word = ""
    for ridx, cidx in zip(range(ridx, len(grid)), range(cidx, -1, -1)):
        running_word += grid[ridx][cidx]
        all_possible_words.add(running_word)
    return all_possible_words

def get_all_possible_down_right(grid, ridx, cidx):
    all_possible_words = set()
    running_word = ""
    for ridx, cidx in zip(range(ridx, len(grid)), range(cidx, len(grid[0]))):
        running_word += grid[ridx][cidx]
        all_possible_words.add(running_word)
    return all_possible_words


T = int(input())
while T:
    T -= 1
    m, n = map(int, input().strip().split())
    grid = [input().strip().lower() for _ in range(m)]
    k = int(input())
    words = [input().strip().lower() for _ in range(k)]
    ALL_POSSIBLES = {}
    for ridx, row in enumerate(grid):
        for cidx, char in enumerate(row):
            all_possible_words = get_all_possible(grid, ridx, cidx)
            for word in all_possible_words:
                ALL_POSSIBLES[word] = min(ALL_POSSIBLES.get(word, (ridx+1, cidx+1)), (ridx+1, cidx+1))
    for word in words:
        if word in ALL_POSSIBLES:
            print(ALL_POSSIBLES[word][0], ALL_POSSIBLES[word][1])
            continue